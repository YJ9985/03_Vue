<template>
  <div>
    <h1>Todo List</h1>
    <!-- 입력파트 -->
    <div>
      <input type="text" v-model.trim="todo" />
      <button @click="addTodo">추가</button>
    </div>
    <!-- 리스트 파트 -->
    <ol>
      <!-- todo 항목 -->
      <li v-for="todoItem in states.todoList" :key="todoItem.id">
        <span :style="todoItem.done ? { textDecoration: 'line-through' } : { textDecoration: 'none' }" v-on:click="toggleTodo(todoItem.id)">
          {{ todoItem.todo }} {{ todoItem.done ? '(완료)' : '' }}</span
        >
        <div v-if="todoItem.editing">
          <input type="text" v-model.trim="todoEdit" />
          <button @click.stop="confirmEditTodo(todoItem.id)">확인</button>
          <button @click.stop="cancelEditTodo(todoItem.id)">취소</button>
        </div>
        &nbsp;
        <span v-if="!todoItem.editing">
          <button @click.stop="editTodo(todoItem.id)">수정</button>
          /
          <button @click.stop="deleteTodo(todoItem.id)">삭제</button>
        </span>
      </li>
    </ol>
  </div>
</template>

<script setup>
import axios from 'axios';
import { ref, reactive } from 'vue';

const states = reactive({
  todoList: [],
});

const todo = ref('');
const todoEdit = ref('');

// localhost:3000
const BaseUrl = '/api/todos';

async function fetchTodoLsit() {
  try {
    const fetchTodoRes = await axios.get(BaseUrl);

    console.log(fetchTodoRes);
    states.todoList = fetchTodoRes.data;
    console.log * states.todoList;
  } catch (e) {
    alert('TodoList Date Connection Error');
    console.log(e);
  }
}

async function addTodo() {
  if (todo.value === '') return alert('Enter a Todo');
  try {
    const newTodo = { todo: todo.value, done: false };
    const addTodoRes = await axios.post(BaseUrl, newTodo);

    if (addTodoRes.status !== 201) return alert('Failed to add todo');

    todo.value = '';
    fetchTodoLsit();
  } catch (e) {
    alert('Error occurred while adding a new Todolist');
    console.log(e);
  }
}

async function toggleTodo(id) {
  try {
    const targetTodo = states.todoList.find((todo) => todo.id === id);
    const payload = { ...targetTodo, done: !targetTodo.done };

    const toggleTodoRes = await axios.put(BaseUrl + `/${id}`, payload);
    if (toggleTodoRes.status !== 200) return alert('Failed to Toggle Todo');
    fetchTodoLsit();
  } catch (e) {
    alert('Error occurred while Toggling Todo');
    console.log(e);
  }
}

async function deleteTodo(id) {
  try {
    const deleteTodoRes = await axios.delete(BaseUrl + `/${id}`);

    if (deleteTodoRes.status !== 200) return alert('Failed to delete todo');
    fetchTodoLsit();
  } catch (e) {
    alert('Error occurred duringd dleting Todo.');
    console.log(e);
  }
}

// 서버랑 통신 안 해도 돼서 async 안 달음
function editTodo(id) {
  const targetTodo = states.todoList.find((todo) => todo.id === id);
  targetTodo.editing = true;
}

function cancelEditTodo(id) {
  const targetTodo = states.todoList.find((todo) => todo.id === id);
  targetTodo.editing = false;
}

async function confirmEditTodo(id) {
  if (todoEdit.value === '') return alert('Edit Todo.');
  try {
    const targetTodo = states.todoList.find((todo) => todo.id === id);
    const payload = { ...targetTodo, todo: todoEdit.value, editing: false };

    const editTodoRes = await axios.put(BaseUrl + `/${id}`, payload);

    if (editTodoRes.status !== 200) return alert('Failed to edit todo');

    todoEdit.value = '';

    fetchTodoLsit();
  } catch (e) {
    alert('Error occurred during Edting Todo');
    console.log(e);
  }
}

fetchTodoLsit();
</script>
