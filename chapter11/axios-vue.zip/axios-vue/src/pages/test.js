const todo = {
  id: '1',
  todo: 'Understand Object',
  done: false,
};

const copyTodo = {
  id: todo.id,
  todo: todo.todo,
  done: true,
};

console.log(todo === copyTodo);
console.log(copyTodo);
